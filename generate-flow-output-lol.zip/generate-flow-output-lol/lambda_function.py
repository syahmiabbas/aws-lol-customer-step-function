import json
import time
import uuid
import boto3
import requests
import os
import botocore.exceptions
import random
from botocore.config import Config
from datetime import datetime

config = Config(read_timeout=1000)

s3 = boto3.client("s3")
bedrock_agent_runtime = boto3.client("bedrock-agent-runtime", region_name='us-east-1', config=config)
bedrock_agent = boto3.client("bedrock-agent", region_name='us-east-1', config=config)

# Optional pricing if needed.  
MODEL_PRICING = {
    "anthropic.claude-3-sonnet-20240229-v1:0": {
        "input_per_1k_tokens": 0.003,
        "output_per_1k_tokens": 0.015
    },
    "anthropic.claude-3-5-sonnet-20240620-v1:0": {
        "input_per_1k_tokens": 0.003,
        "output_per_1k_tokens": 0.015
    },
    "anthropic.claude-3-haiku-20240307-v1:0": {
        "input_per_1k_tokens": 0.0008,
        "output_per_1k_tokens": 0.004
    },
    "anthropic.claude-v2:1": {
        "input_per_1k_tokens": 0.008,
        "output_per_1k_tokens": 0.024
    },
    "amazon.nova-micro-v1:0": {
        "input_per_1k_tokens": 0.000035,
        "output_per_1k_tokens": 0.00014
    },
    "amazon.nova-pro-v1:0": {
        "input_per_1k_tokens": 0.0008,
        "output_per_1k_tokens": 0.0032
    },
    "amazon.nova-lite-v1:0": {
        "input_per_1k_tokens": 0.00006,
        "output_per_1k_tokens": 0.00024
    }
}

def create_flow_version_and_alias_once(flow_id, flow_alias):
    # List all aliases
    aliases = bedrock_agent.list_flow_aliases(flowIdentifier=flow_id)
    
    existing_alias = None
    for alias in aliases.get("aliases", []):
        if alias["name"] != "":
            existing_alias = alias
            break

    # List all versions
    versions = bedrock_agent.list_flow_versions(flowIdentifier=flow_id).get("flowVersions", [])

    # Delete all previous versions
    for version in versions:
        bedrock_agent.delete_flow_version(
            flowIdentifier=flow_id,
            flowVersion=version["version"]
        )
        print(f"Deleted old flow version: {version['version']}")

    # Create a new version
    version_response = bedrock_agent.create_flow_version(flowIdentifier=flow_id)
    flow_version = version_response["version"]
    print(f"Created flow version: {flow_version}")

    if existing_alias:
        # Update existing alias to point to new version
        bedrock_agent.update_flow_alias(
            flowIdentifier=flow_id,
            flowAliasId=existing_alias["id"],
            routingConfiguration=[{"flowVersion": flow_version}]
        )
        print(f"Updated existing alias {existing_alias['name']} to new version")
        return existing_alias["id"]
    else:
        # Create a new alias
        alias_name = f"auto-alias-{uuid.uuid4().hex[:8]}"
        alias_response = bedrock_agent.create_flow_alias(
            flowIdentifier=flow_id,
            name=alias_name,
            routingConfiguration=[{"flowVersion": flow_version}]
        )
        flow_alias_id = alias_response["id"]
        print(f"Created new flow alias: {flow_alias_id}")
        return flow_alias_id


def find_model_ids(obj, key_to_find="modelId"):
    """
    Recursively searches for all values with key `modelId` in nested dictionaries/lists.
    Returns the first match or list of matches if needed.
    """
    matches = []

    if isinstance(obj, dict):
        for key, value in obj.items():
            if key == key_to_find:
                matches.append(value)
            else:
                matches.extend(find_model_ids(value, key_to_find))
    elif isinstance(obj, list):
        for item in obj:
            matches.extend(find_model_ids(item, key_to_find))
    
    return matches

def get_model_id_from_flow(flow_id):
    response = bedrock_agent.get_flow(
        flowIdentifier=flow_id
    )

    print("Retrieved bedrock flow details:")
    print(response)

    definition = response.get("definition", {})
    model_ids = find_model_ids(definition)

    if not model_ids:
        raise ValueError("No modelId found in flow definition.")

    # If multiple model IDs are found, ensure they are the same
    if len(set(model_ids)) > 1:
        raise ValueError("Multiple different modelIds found in flow definition.")

    return model_ids[0]

def load_instructions_from_file_original(filepath="instructions.json"):
    with open(filepath, "r") as f:
        data = json.load(f)
    return data
    
def load_instructions_from_file(filepath="instructions.json"):
    with open(filepath, "r") as f:
        data = json.load(f)
    return [item["instruction"] for item in data if "instruction" in item]

def call_prompt_flow(flow_id, flow_alias, prompt, max_retries=5):
    print("Invoking prompt flow")
    print(flow_alias)

    # Create flow version and alias
    if flow_alias == "":
        print("ALIAS EMPTY")
        flow_alias = create_flow_version_and_alias_once(flow_id, flow_alias)
        print(flow_alias)
    
    # create flow version and attach to existing alias
    else:
        print("ALIAS NOT EMPTY")
        flow_alias = flow_alias
        print(flow_alias)

    retry_delay = 1  # initial delay in seconds
    for attempt in range(1, max_retries + 1):
        try:
            start_time = time.time()

            response = bedrock_agent_runtime.invoke_flow(
                enableTrace=False,
                flowIdentifier=flow_id,
                flowAliasIdentifier=flow_alias,
                inputs=[
                    {
                        'content': {
                            'document': prompt
                        },
                        'nodeName': 'FlowInputNode',
                        'nodeOutputName': 'document'
                    }
                ]
            )

            
            event_stream = response["responseStream"]
            print(event_stream)
            for event in event_stream:
                print(event)
                if "flowOutputEvent" in event:
                    evalResponse = event["flowOutputEvent"]["content"]["document"]

            end_time = time.time()
            latency = end_time - start_time
            print(f"Latency: {latency}")

            avg_chars_per_token = 4  # rough estimate

            print("------- INPUT TOKEN NUMBER OF WORDS ---------------")
            total_words = sum(len(sentence.split()) for sentence in prompt)
            print(total_words)
            input_tokens = total_words // avg_chars_per_token
            print(f"Input tokens: {input_tokens}")

            print("------- OUTPUT TOKENS NUMBER OF WORDS ---------------")
            total_output_words = sum(len(sentence.split()) for sentence in evalResponse)
            print(total_output_words)
            output_tokens = total_output_words // avg_chars_per_token
            print(f"Output tokens: {output_tokens}")

            return {
                "output": evalResponse,
                "latency": latency,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens
            }
        except botocore.exceptions.ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "dependencyFailedException" or e.response["ResponseMetadata"]["HTTPStatusCode"] == 429:
                print(f"Attempt {attempt} failed with rate limit: {str(e)}")
                if attempt == max_retries:
                    raise e
                sleep_time = retry_delay + random.uniform(0, 1)
                print(f"Retrying in {sleep_time:.2f} seconds...")
                time.sleep(sleep_time)
                retry_delay *= 2  # exponential backoff
            else:
                raise e

def calculate_cost(baseModelId, model_id, input_tokens, output_tokens):
    pricing = MODEL_PRICING.get(baseModelId, {"input_per_1k_tokens": 0, "output_per_1k_tokens": 0})
    return (input_tokens / 1000) * pricing["input_per_1k_tokens"] + (output_tokens / 1000) * pricing["output_per_1k_tokens"]

def lambda_handler(event, context):
    flow_id = event.get("trainingName", "") # Flow ID
    print(flow_id)
    flow_alias = event.get("flowAlias", "") #Flow Alias
    print(flow_alias)

    modelId = event["modelId"]
    task_token = event["TaskToken"]
    leaderboardId = event["leaderboardId"]
    userId = event["userId"]
    eventType = event["eventType"]
    executionName = event["executionName"]
    reference_outputs = event["reference_outputs"]

    # if flow ID
    if len(flow_id) == 10:
        print("Valid flow ID length")

        try:
            baseModelId = get_model_id_from_flow(flow_id)
            print(f"Base model ID: {baseModelId}")

            instructions_data = load_instructions_from_file()
            print(f"Loaded instructions: {instructions_data}")

            results = []
            total_latency = 0
            total_cost = 0

            # prompt = item["instruction"]
            result = call_prompt_flow(flow_id, flow_alias, instructions_data, max_retries=5)
            print(f"Result: {result}")
            print(result["output"])
            print(result["latency"])
            latency = result["latency"]
            print(result["input_tokens"])
            input_tokens_count = result["input_tokens"]
            print(result["output_tokens"])
            output_tokens_count = result["output_tokens"]

            cost = calculate_cost(baseModelId, modelId, input_tokens_count, output_tokens_count)
            print("-------COST-------")
            print(cost)

            total_cost += cost
            total_latency += latency

            instructions_data_original = load_instructions_from_file_original()

            # Update the output field for each instruction
            if len(result["output"]) != len(instructions_data_original):
                raise ValueError("Mismatch between number of instructions and returned outputs")

            for i in range(len(instructions_data_original)):
                instructions_data_original[i]["output"] = result["output"][i]

            updated_path = "/tmp/instructions-updated.json"
            with open(updated_path, "w") as f:
                json.dump(instructions_data_original, f, indent=2)

            print(f"Updated instructions written to: {updated_path}")

            # Save to S3
            bucket = "asean-llm-league-output-json-bucket"
            key = f"prompt-flow-results/{flow_id}-{uuid.uuid4()}.jsonl"

            summary = {
                "average_latency": total_latency,
                "average_cost": total_cost
            }

            for idx, output in enumerate(result["output"]):
                results.append({
                    "prompt": instructions_data_original[idx]["instruction"],
                    "output": output
                })

            print("Updated results")
            print(results)

            s3_body = "\n".join(json.dumps(r) for r in results) + "\n" + json.dumps(summary)

            s3.put_object(Bucket=bucket, Key=key, Body=s3_body.encode("utf-8"))
            model_outputs = f"s3://{bucket}/{key}"

            # Build API Gateway URL
            payload = json.dumps({"body": event["TaskToken"]})
            headers = {"Content-Type": "application/json"}

            api_gateway_url = f'https://4xkf7lc0wg.execute-api.us-east-1.amazonaws.com/dev/invokeSF?TaskToken={task_token}&model_outputs={model_outputs}&endpointName=xxx&modelId={modelId}&leaderboardId={leaderboardId}&trainingName={flow_id}&userId={userId}&eventType={eventType}&executionName={executionName}&average_latency={total_latency}&average_cost={total_cost}&reference_outputs={reference_outputs}'

            print("INVOKING STEP FUNCTIONS API")
            response = requests.post(api_gateway_url, data=payload, headers=headers)

            print(f"Final total latency: {total_latency}")
            print(f"Final total cost: {total_cost}")

            return {
                "statusCode": 200,
                "body": json.dumps({
                    "model_outputs": model_outputs
                })
            }
        
        except Exception as e:
            print("-------ERROR MESSAGE--------")
            print(f"An error occurred: {e}")

            error_message = str(e)

            api_gateway_url = f'https://4xkf7lc0wg.execute-api.us-east-1.amazonaws.com/dev/invokeSF?TaskToken={task_token}&model_outputs=xxx&endpointName=xxx&modelId={modelId}&leaderboardId={leaderboardId}&trainingName={flow_id}&userId={userId}&eventType={eventType}&reference_outputs={reference_outputs}&executionName={executionName}&errorMessage={e}'

            payload = json.dumps({"body": event["TaskToken"]})
            headers = {"Content-Type": "application/json"}

            response = requests.post(api_gateway_url, data=payload, headers=headers)

            return {
                'status': 500,
                'errorMessage': error_message
            }
        
    # project ID
    else:
        # List all flows
        flows = bedrock_agent.list_flows()
        flow_summaries = flows.get("flowSummaries", [])

        latest_flow = None

        for flow in flow_summaries:
            description = flow.get("description", "")
            if f"project {flow_id}" in description:
                if latest_flow is None or flow["createdAt"] > latest_flow["createdAt"]:
                    latest_flow = flow
        
        if latest_flow:
            # Extract flow ID from ARN
            arn = latest_flow["arn"]
            flow_id = arn.split("/")[-1]
            print("Latest Flow ID:", flow_id)
        else:
            print("No matching flow found.")

        try:
            baseModelId = get_model_id_from_flow(flow_id)
            print(f"Base model ID: {baseModelId}")

            instructions_data = load_instructions_from_file()
            print(f"Loaded instructions: {instructions_data}")

            results = []
            total_latency = 0
            total_cost = 0

            result = call_prompt_flow(flow_id, flow_alias, instructions_data, max_retries=5)
            print(f"Result: {result}")
            print(result["output"])
            print(result["latency"])
            latency = result["latency"]
            print(result["input_tokens"])
            input_tokens_count = result["input_tokens"]
            print(result["output_tokens"])
            output_tokens_count = result["output_tokens"]

            cost = calculate_cost(baseModelId, modelId, input_tokens_count, output_tokens_count)
            print("-------COST-------")
            print(cost)

            total_cost += cost
            total_latency += latency

            instructions_data_original = load_instructions_from_file_original()

            # Update the output field for each instruction
            if len(result["output"]) != len(instructions_data_original):
                raise ValueError("Mismatch between number of instructions and returned outputs")

            for i in range(len(instructions_data_original)):
                instructions_data_original[i]["output"] = result["output"][i]

            updated_path = "/tmp/instructions-updated.json"
            with open(updated_path, "w") as f:
                json.dump(instructions_data_original, f, indent=2)

            print(f"Updated instructions written to: {updated_path}")

            # Save to S3
            bucket = "asean-llm-league-output-json-bucket"
            key = f"prompt-flow-results/{flow_id}-{uuid.uuid4()}.jsonl"

            summary = {
                "average_latency": total_latency,
                "average_cost": total_cost
            }

            for idx, output in enumerate(result["output"]):
                results.append({
                    "prompt": instructions_data_original[idx]["instruction"],
                    "output": output
                })

            print("Updated results")
            print(results)

            s3_body = "\n".join(json.dumps(r) for r in results) + "\n" + json.dumps(summary)

            s3.put_object(Bucket=bucket, Key=key, Body=s3_body.encode("utf-8"))
            model_outputs = f"s3://{bucket}/{key}"

            # Build API Gateway URL
            payload = json.dumps({"body": event["TaskToken"]})
            headers = {"Content-Type": "application/json"}

            api_gateway_url = f'https://4xkf7lc0wg.execute-api.us-east-1.amazonaws.com/dev/invokeSF?TaskToken={task_token}&model_outputs={model_outputs}&endpointName=xxx&modelId={modelId}&leaderboardId={leaderboardId}&trainingName={flow_id}&userId={userId}&eventType={eventType}&executionName={executionName}&average_latency={total_latency}&average_cost={total_cost}&reference_outputs={reference_outputs}'

            print("INVOKING STEP FUNCTIONS API")
            response = requests.post(api_gateway_url, data=payload, headers=headers)

            print(f"Final total latency: {total_latency}")
            print(f"Final total cost: {total_cost}")

            return {
                "statusCode": 200,
                "body": json.dumps({
                    "model_outputs": model_outputs
                })
            }
        
        except Exception as e:
            print("-------ERROR MESSAGE--------")
            print(f"An error occurred: {e}")

            error_message = str(e)

            api_gateway_url = f'https://4xkf7lc0wg.execute-api.us-east-1.amazonaws.com/dev/invokeSF?TaskToken={task_token}&model_outputs=xxx&endpointName=xxx&modelId={modelId}&leaderboardId={leaderboardId}&trainingName={flow_id}&userId={userId}&eventType={eventType}&reference_outputs={reference_outputs}&executionName={executionName}&errorMessage={e}'

            payload = json.dumps({"body": event["TaskToken"]})
            headers = {"Content-Type": "application/json"}

            response = requests.post(api_gateway_url, data=payload, headers=headers)

            return {
                'status': 500,
                'errorMessage': error_message
            }